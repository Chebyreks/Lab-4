﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab4
{
    internal class Interface
    {
        public static void PrintMenu(int x, int y, string[] menu, int active_row)
        {

            Console.BackgroundColor = ConsoleColor.Blue;
            Console.ForegroundColor = ConsoleColor.White;

            for (int i = 0; i < menu.Length; i++)
            {
                Console.SetCursorPosition(x, y + i);
                Console.Write(menu[i]);
            }
            Console.BackgroundColor = ConsoleColor.Yellow;
            Console.ForegroundColor = ConsoleColor.Black;
            Console.SetCursorPosition(x, y + active_row);
            Console.Write(menu[active_row]);
        }

        public static void PrintMenu(int x, int y, Good[] menu, int active_row) // Перегрузочка
        {
            string[] str_arr = new string[menu.Length];
            for (int i = 0; i < str_arr.Length; i++)
            {
                str_arr[i] = menu[i].Name;
            }
            PrintMenu(x, y, str_arr, active_row);
        }

        public static void PrintMisc(int x)
        {
            Console.SetCursorPosition(x, 1);
            Console.Write('║');
            Console.SetCursorPosition(x, 2);
            Console.Write('║');
            Console.SetCursorPosition(1, 12);
            Console.Write("-----<Enter - Выбрать>, <A, D - Перейти в другое меню>, <W, S - вверх, вниз>-----");
        }

        public static void PrintResult(int x, int y)
        {
            Good[] chosen = Bin.Get_Chosen_Goods();
            Console.SetCursorPosition(x, y);
            string[] str_arr = new string[chosen.Length];
            for (int i = 0; i < str_arr.Length; i++)
            {
                str_arr[i] = chosen[i].Name;
            }
            for (int i = 0; i < Bin.Get_Chosen_Goods().Length; i++)
            {
                Console.SetCursorPosition(x, y + i);
                Console.Write(str_arr[i]);
            }
        }

        public static void DrawLine(int x, int y, int count, bool vertical)
        {
            if (vertical)
            {
                for (int i = 0; i < count; i++)
                {
                    Console.SetCursorPosition(x, y + i);
                    Console.Write("║");
                }
            }
            else
            {
                for (int i = 0; i < count; i++)
                {
                    Console.SetCursorPosition(x + i, y);
                    Console.Write("═");
                }
            }

        }

        public static void PrintBorders()
        {
            Console.SetCursorPosition(0, 2);
            Console.Write('╔');
            DrawLine(1, 2, 81, false);
            Console.Write('╗');
            Console.SetCursorPosition(43, 2);
            Console.Write('╦');
            DrawLine(1, 11, 81, false);
            DrawLine(1, 13, 81, false);
            DrawLine(0, 3, 8, true);
            DrawLine(0, 12, 1, true);
            DrawLine(43, 3, 8, true);
            DrawLine(43, 12, 1, true);
            DrawLine(82, 3, 8, true);
            DrawLine(82, 12, 1, true);
            Console.SetCursorPosition(0, 11);
            Console.Write('╠');
            Console.SetCursorPosition(0, 13);
            Console.Write('╚');
            Console.SetCursorPosition(43, 11);
            Console.Write('╩');
            Console.SetCursorPosition(82, 11);
            Console.Write('╣');
            Console.SetCursorPosition(82, 13);
            Console.Write('╝');
        }
    }
}
