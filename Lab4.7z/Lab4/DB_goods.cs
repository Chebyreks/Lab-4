﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Lab4.Good;

namespace Lab4
{
    internal class DB_goods
    {
        private static Good[] Goods_Arr = { new("Малая шаурма с говядиной", 160, 2),
            new("Средняя шаурма с говядиной", 220, 2),
            new("Малая шаурма со свининой", 170, 2),
            new("Средняя шаурма со свининой", 240, 3),
            new("Малая шаурма с курицей", 150, 3),
            new("Средняя шаурма с курицей", 200, 2)};

        public static Good[] Get_Goods() { return Goods_Arr; }
        public static int Len() { return Goods_Arr.Length; }
    }
}
