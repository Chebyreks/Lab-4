﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab4
{
    internal class Good
    {
        private string name_;
        private int count_;
        private int price_;


        public string Name { get => name_; set => name_ = value; }
        public int Price { get => price_; set => price_ = value; }
        public int Count { get => count_; set => count_ = value; }

        public Good(string name_, int price_, int count_)
        {
            Name = name_;
            Price = price_;
            Count = count_;
        }
    }
}
