﻿using System;
using System.Drawing;
using System.Runtime.ExceptionServices;
using static Lab4.Bin;
using static Lab4.DB_goods;
using static Lab4.Interface;
using static Lab4.Good;
namespace Lab4
{
    internal class Program
    {
        static string[] COMMANDS = { "Просмотреть продукты / добавить в корзину", "Просмотреть корзину / удалить из корзины", "Закончить заказ" };

        static bool PrintMenus(ref int active_col, ref int active_menu, int[] active_row, bool input)
        {
            bool end = false;
            if (input)
            {
                switch (active_col)
                {
                    case 0:
                        active_menu = active_row[0] + 1;
                        active_row[1] = 0;
                        break;
                    case 1:
                        switch (active_menu)
                        {
                            case 1:
                                Bin.Add(DB_goods.Get_Goods()[active_row[1]]);
                                break;
                            case 2:
                                Bin.Remove(Bin.Get_Chosen_Goods()[active_row[1]]);
                                if (active_row[1] >= Bin.Get_Chosen_Goods().Length)
                                {
                                    active_row[1]--;
                                }
                                break;
                        }

                        break;
                }
            }
            Console.BackgroundColor = ConsoleColor.Black;
            Console.Clear();
            PrintMenu(1, 3, COMMANDS, active_row[0]);
            switch (active_menu)
            {
                case 1:
                    PrintMenu(45, 3, DB_goods.Get_Goods(), active_row[1]);
                    break;
                case 2:
                    PrintMenu(45, 3, Bin.Get_Chosen_Goods(), active_row[1]);
                    break;
                case 3:
                    Console.BackgroundColor = ConsoleColor.Yellow;
                    Console.ForegroundColor = ConsoleColor.Black;
                    Console.SetCursorPosition(1, 15);
                    Console.Write("Стоимость купленных продуктов: ");
                    Console.Write(Bin.Get_Sum());
                    PrintResult(1, 16);
                    end = true;
                    break;
            }
            int coord = 0;
            if (active_col == 0)
            {
                coord = 1;
            }
            else
            {
                coord = 45;
            }
            PrintBorders();
            PrintMisc(coord);

            if (end)
            {
                return true;
            }
            return false;
        }

        static void ConsoleLoop()
        {
            bool isWorking = true;
            int active_col = 0;
            int active_menu = 0;
            int[] active_row = { 0, 0 };
            bool input = false;
            PrintMenus(ref active_col, ref active_menu, active_row, input);
            while (isWorking)
            {
                ConsoleKeyInfo info = Console.ReadKey();
                switch (info.Key)
                {
                    case ConsoleKey.Enter:
                        input = true;
                        break;

                    case ConsoleKey.LeftArrow:
                        if (active_menu != 0 && active_col > 0)
                        {
                            active_col--;
                        }
                        break;
                    case ConsoleKey.RightArrow:
                        if (active_menu != 0 && active_col < 1)
                        {
                            active_col++;
                        }
                        break;
                    case ConsoleKey.UpArrow:
                        if (active_row[active_col] > 0)
                        {
                            active_row[active_col]--;
                        }
                        break;
                    case ConsoleKey.DownArrow:
                        if (active_col == 0 && active_row[0] < 2)
                        {
                            active_row[active_col]++;
                        }
                        else if (active_col == 1)
                        {
                            if (active_menu == 1 && active_row[active_col] < DB_goods.Get_Goods().Length - 1)
                            {
                                active_row[active_col]++;
                            }
                            else if (active_menu == 2 && active_row[active_col] < Bin.Get_Chosen_Goods().Length - 1)
                            {
                                active_row[active_col]++;
                            }
                        }
                        break;
                }
                bool end = PrintMenus(ref active_col, ref active_menu, active_row, input);
                input = false;
                if (end)
                {
                    break;
                }
            }
        }


        static void Main(string[] args)
        {
            Console.BackgroundColor = ConsoleColor.Black;
            Console.Clear();
            ConsoleLoop();
            Console.SetCursorPosition(1, 16);
            Console.ReadLine();
        }
    }
}
