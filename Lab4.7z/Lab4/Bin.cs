﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Lab4.Good;

namespace Lab4
{
    internal class Bin
    {
        private static List<Good> Chosen_Goods = [new("Ничего пока что(", 0, 0)];
        private static int Count = 0;


        private static bool ApproveAdd()
        {
            if (Count == 0)
            {
                Chosen_Goods.Clear();
            }
            return true;
        }
        private static bool ApproveDelete()
        {
            if (Count == 0)
            {
                return false;
            }

            if (Count == 1)
            {
                Chosen_Goods.Add(new("Ничего пока что(", 0, 0));
            }
            return true;
        }
        public static void Add(Good good)
        {
            if (ApproveAdd())
            {
                Chosen_Goods.Add(good);
                Count++;
            }
        }

        public static void Remove(Good good)
        {
            if (ApproveDelete())
            {
                Chosen_Goods.Remove(good);
                Count--;
            }
        }

        public static Good[] Get_Chosen_Goods() { return Chosen_Goods.ToArray(); }

        public static int Get_Sum()
        {
            int sum = 0;
            if (Chosen_Goods != null)
            {
                foreach (Good good in Chosen_Goods)
                {
                    sum += good.Price;
                }
            }
            return sum;
        }
    }
}
